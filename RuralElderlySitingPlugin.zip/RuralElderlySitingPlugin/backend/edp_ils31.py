import SSCFLP_MH31 as d
#import SSCFLP_MH23 as d
import time,sys,random,math
#to solve benchmark instances
maxr=1.0
maxr2=2.0
maxcp=80
spp=0 #set partitioning
psize=1 #population size
maxloops=20 #max_loops_solution_not_improved
t=7200 #timelimit for searching
nf=0 # number of facilities, number of service areas
mthd=0
max_mean=5#10.0  #4~20, 20 for CPMP group5, ali525
distance_type=2
avg_dis=1.0
alpha=1.0
mincap=0
max_cost=0
fn2="na"
filetype=0
deviation=0.05
allcand=0
if len(sys.argv) >= 2:
    fn=sys.argv[1]
if len(sys.argv) >= 3:
    fn2=sys.argv[2]    
if len(sys.argv) >= 4:
    nf=int(sys.argv[3])
if len(sys.argv) >= 5:
    deviation=float(sys.argv[4])
if len(sys.argv) >= 6:
    psize=int(sys.argv[5])
if len(sys.argv) >= 7:
    maxloops=int(sys.argv[6])
if len(sys.argv) >= 8:
    mthd=int(sys.argv[7])
if len(sys.argv) >= 9:
    allcand=int(sys.argv[8])

#if alpha<0: alpha=8/avg_dis
t0=time.time()
d.location_problem=2 #EDP,PDP
d.all_units_as_candadate_locations=allcand
d.fixed_cost_obj=0
d.max_num_facility=nf
d.adaptive_number_of_facilities=0
d.spatial_contiguity=01
d.pop_dis_coeff=100000
d.penalty_on_demand=100000
d.pop_deviation=deviation #for PDP
d.distance_type=0
d.multi_start_count=psize
d.max_loops_solution_not_improved=maxloops
#read instance file(s)
d.readfile(fn,fn2) #read self-defined instances
#max min cap

cap=1.0*d.total_pop/nf
for i in range(d.num_districts):
    d.facilityCapacity[i]=cap
d.initial_solution_method=mthd
d.multi_start_count=psize
d.max_loops_solution_not_improved=maxloops
d.ruin_oprators=[0,1,3]
d.ruin_percentage=10
d.is_spp_modeling=1
'''
d.solver_message=01
if d.spatial_contiguity==0:
    d.EDP_mip_model(nf,deviation,t,0.0000001)
else:
    d.spatial_contiguity=0
    d.EDP_mip_model(nf,deviation,t,0.005)
    d.spatial_contiguity=1
    d.repair_fragmented_solution()
    d.VND_local_search()
    d.EDP_mip_model(nf,deviation,t,0.0000001)'''
if mthd==0:
    d.EDP_ils(nf)
if mthd==1:
    d.EDP_ils(nf)
    d.solver_message=1
    d.EDP_mip_model(nf,deviation,t,0.0000001)
if mthd==2:
    d.EDP_ils(nf)
    d.solver_message=1
    d.SAP_model()
if mthd==3:
    kmobj,centers,sol=d.multi_w_k_medoids(10,50,0)
    d.centersID=[-1 for x in range(d.num_districts)]
    for x in centers: d.centersID[x]=d.nodes[x][0]
    print d.centersID
    d.solver_message=1
    d.SAP_model()
if mthd==4:
    kmobj,centers,sol=d.multi_w_k_medoids(5,100,0)
    d.centersID=[-1 for x in range(d.num_districts)]
    d.node_groups=sol[:]
    for x in centers: d.centersID[x]=d.nodes[x][0]
    d.SAP_ils()


print "=========================Final results========================="
print "pool size",len(d.region_pool)
print "total time",time.time()-t0

print "facilities selected",[x for x in d.centersID if x>=0]
#print "demand:", [d.nodes[x][3] for x in range(d.num_units)]
#print "demand assignment:", d.node_groups
#print "assignment cost:", [(x,d.nodes[x][3],d.nodedij[x][d.node_groups[x]]) for x in range(d.num_units)]

print "service area stat:"
for i in range(d.num_districts):
    if d.district_info[i][0]==0: continue
    print d.facilityCandidate[i],d.district_info[i], d.district_info[i][2]/d.district_info[i][1],
    print "continuality?",d.check_continuality_feasibility(d.node_groups,i)
d.search_stat()
sol=d.sol_stat()
print "=========================Objectives========================="
for x in sol:
    print x,sol[x]
print "-----------equality measures---------------"
equality_measures=d.print_equality_measures()
for x in equality_measures:
    print  x,equality_measures[x]    
print "CPU_time",time.time()-t0
'''
print "solution:"
for x in range(d.num_units):
    print d.nodes[x][0],d.nodes[x][1],d.nodes[x][2],d.nodes[x][3],d.node_groups[x]
'''

def save_sol_location_problem():
    fn2=fn+"_equal_workload_"+str(nf)+".txt"
    f = open(fn2,"w")
    idx=0
    f.write("ID\tDemand	X\tY\tR1\tR2\tCapa\tCenter\tdist\tcovered\n")
    for i in range(d.num_units):
        s=str(d.nodes[i][4])+"\t"+str(d.nodes[i][3])+"\t"+str(d.nodes[i][1])+"\t"+str(d.nodes[i][2])+"\t0\t0\t"
        k=d.node_groups[i]
        uk=d.facilityCandidate[k]
        uk=d.nodes[uk][4]
        c=0
        if i in d.centersID:
            k=d.centersID.index(i)
            c=d.facilityCapacity[k]
        s+=str(c)
        s+="\t"+str(uk)  #center ID
        s+="\t"+str(d.nodedij[i][k]) #distance
        s+="\t"+str(d.district_info[k][1])+"\n" #capa
        f.write(s)
    f.close()
save_sol_location_problem()
    